import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import os
import time
from scipy import linalg
from householder_qr import householder_qr, apply_q_transpose, solve_triangular

def create_blurring_kernel(n, j, k):
    A = np.zeros((n, n))
    coeffs = np.arange(k, 0, -1) * (2 / (k * (k + 1)))
    
    for i in range(n):
        start_idx = min(i + j, n - 1)
        end_idx = max(start_idx - k + 1, 0)
        valid_coeffs = coeffs[-(start_idx - end_idx + 1):]
        A[i, end_idx:(start_idx + 1)] = valid_coeffs[::-1]
    
    return A

def deblur_lu(B, Al, Ar):
    try:
        epsilon = 1e-10
        Al_reg = Al + epsilon * np.eye(Al.shape[0])
        Ar_reg = Ar + epsilon * np.eye(Ar.shape[0])
        lu_l, piv_l = linalg.lu_factor(Al_reg)
        lu_r, piv_r = linalg.lu_factor(Ar_reg)
        Y = linalg.lu_solve((lu_l, piv_l), B)
        X = linalg.lu_solve((lu_r, piv_r), Y.T).T
        return np.clip(X, 0, 1)
    except Exception as e:
        print(f"Error in LU deblurring: {str(e)}")
        return None

def deblur_custom_qr(B, Al, Ar):
    """
    Deblur image using our custom Householder QR factorization.
    """
    try:
        epsilon = 1e-10
        Al_reg = Al + epsilon * np.eye(Al.shape[0])
        Ar_reg = Ar + epsilon * np.eye(Ar.shape[0])
        
        # QR factorization of Al
        R_l, vs_l = householder_qr(Al_reg, compute_q=False)
        # QR factorization of Ar
        R_r, vs_r = householder_qr(Ar_reg, compute_q=False)
        
        # Solve Al * Y = B using QR factorization
        # First apply Q_l^T to B
        Y = np.zeros_like(B)
        for i in range(B.shape[1]):
            Y[:, i] = apply_q_transpose(vs_l, B[:, i])
        # Then solve R_l * Y = Q_l^T * B
        for i in range(B.shape[1]):
            Y[:, i] = solve_triangular(R_l, Y[:, i])
        
        # Solve Y * Ar = X using QR factorization
        # First apply Q_r^T to Y^T
        X = np.zeros_like(Y)
        for i in range(Y.shape[0]):
            X[i, :] = apply_q_transpose(vs_r, Y[i, :])
        # Then solve R_r * X^T = Q_r^T * Y^T
        for i in range(Y.shape[0]):
            X[i, :] = solve_triangular(R_r, X[i, :])
        
        return np.clip(X, 0, 1)
    except Exception as e:
        print(f"Error in custom QR deblurring: {str(e)}")
        return None

def process_image(image_path, output_dir, j1, k1, j2, k2):
    try:
        img = Image.open(image_path).convert('L')
        img_array = np.array(img, dtype=float) / 255.0
        n = img_array.shape[0]
        
        Al = create_blurring_kernel(n, j1, k1)
        Ar = create_blurring_kernel(n, j2, k2)
        blurred = Al @ img_array @ Ar
        
        # LU deblurring
        start_time = time.time()
        deblurred_lu = deblur_lu(blurred, Al, Ar)
        lu_time = time.time() - start_time
        
        # Custom QR deblurring
        start_time = time.time()
        deblurred_custom_qr = deblur_custom_qr(blurred, Al, Ar)
        custom_qr_time = time.time() - start_time
        
        # Calculate relative errors
        rel_error_lu = np.inf if deblurred_lu is None else linalg.norm(deblurred_lu - img_array, 'fro') / linalg.norm(img_array, 'fro')
        rel_error_custom_qr = np.inf if deblurred_custom_qr is None else linalg.norm(deblurred_custom_qr - img_array, 'fro') / linalg.norm(img_array, 'fro')
        
        # Plot results
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        plt.figure(figsize=(15, 10))
        
        plt.subplot(221)
        plt.imshow(img_array, cmap='gray')
        plt.title('Original')
        plt.axis('off')
        
        plt.subplot(222)
        plt.imshow(blurred, cmap='gray')
        plt.title('Blurred')
        plt.axis('off')
        
        plt.subplot(223)
        if deblurred_lu is not None:
            plt.imshow(deblurred_lu, cmap='gray')
            plt.title(f'LU Deblurred\nTime: {lu_time:.3f}s\nError: {rel_error_lu:.6f}')
        else:
            plt.title('LU Deblurring Failed')
        plt.axis('off')
        
        plt.subplot(224)
        if deblurred_custom_qr is not None:
            plt.imshow(deblurred_custom_qr, cmap='gray')
            plt.title(f'Custom QR Deblurred\nTime: {custom_qr_time:.3f}s\nError: {rel_error_custom_qr:.6f}')
        else:
            plt.title('Custom QR Deblurring Failed')
        plt.axis('off')
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f'{base_name}_comparison_custom_k{k2}.png'))
        plt.close()
        
        return {
            'lu_time': lu_time,
            'custom_qr_time': custom_qr_time,
            'lu_error': rel_error_lu,
            'custom_qr_error': rel_error_custom_qr
        }
    except Exception as e:
        print(f"Error processing image {image_path}: {str(e)}")
        return None

def main():
    input_dir = "/Users/songyutong/Desktop"
    output_dir = "/Users/songyutong/CascadeProjects/image_deblurring/output"
    os.makedirs(output_dir, exist_ok=True)
    
    image_files = ["1250_m1_original.png", "1250_m3_original.png"]
    j_Al = 0
    k_Al = 12
    j_Ar = 1
    k_Ar_values = [24, 36]
    
    results = []
    
    for img_file in image_files:
        input_path = os.path.join(input_dir, img_file)
        for k_Ar in k_Ar_values:
            print(f"\nProcessing {img_file} with k_Ar = {k_Ar}...")
            result = process_image(input_path, output_dir, j_Al, k_Al, j_Ar, k_Ar)
            if result is not None:
                results.append({
                    'image': img_file,
                    'k_Ar': k_Ar,
                    **result
                })

    if results:
        print("\nSummary of Results:")
        print("-" * 100)
        print(f"{'Image':<20} {'k_Ar':>5} {'LU Time':>10} {'Custom QR':>10} {'LU Error':>10} {'Custom QR':>10}")
        print("-" * 100)
        for r in results:
            print(f"{r['image']:<20} {r['k_Ar']:>5d} {r['lu_time']:>10.3f} {r['custom_qr_time']:>10.3f} "
                  f"{r['lu_error']:>10.6f} {r['custom_qr_error']:>10.6f}")
    else:
        print("\nNo successful results to display.")

if __name__ == "__main__":
    main()
