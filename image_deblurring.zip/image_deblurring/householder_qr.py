import numpy as np

def householder_vector(x):
    """
    Compute the Householder vector v for a given vector x.
    The vector v is chosen such that P = I - 2vv^T/v^Tv transforms x to ||x||e_1
    """
    n = len(x)
    if n == 1:
        return np.array([1.0])
    
    # Compute norm of x
    norm_x = np.linalg.norm(x)
    if norm_x == 0:
        return np.zeros_like(x)
    
    # First component of the transformed vector
    sigma = -np.sign(x[0]) * norm_x
    
    # Construct v
    v = x.copy()
    v[0] = x[0] - sigma
    
    # Normalize v
    v = v / np.linalg.norm(v)
    
    return v

def householder_qr(A, compute_q=False):
    """
    Compute the QR factorization of matrix A using Householder reflections.
    
    Args:
        A (numpy.ndarray): Input matrix of shape (m, n) where m >= n
        compute_q (bool): If True, explicitly compute Q matrix
        
    Returns:
        R (numpy.ndarray): Upper triangular matrix
        Q (numpy.ndarray): Orthogonal matrix (only if compute_q=True)
        vs (list): List of Householder vectors (only if compute_q=False)
    """
    m, n = A.shape
    if m < n:
        raise ValueError("Input matrix must have m >= n")
    
    R = A.copy()
    vs = []  # Store Householder vectors
    
    for k in range(n):
        # Extract the column vector below diagonal
        x = R[k:, k]
        
        # Compute Householder vector
        v = householder_vector(x)
        vs.append(v)
        
        # Apply Householder reflection to remaining columns
        for j in range(k, n):
            # R[k:, j] = R[k:, j] - 2v(v^T R[k:, j])
            R[k:, j] = R[k:, j] - 2 * v * (v @ R[k:, j])
    
    if compute_q:
        # Explicitly construct Q matrix
        Q = np.eye(m)
        for k in range(n-1, -1, -1):
            v = vs[k]
            # Apply Householder reflection to columns of Q
            Q[k:, :] = Q[k:, :] - 2 * np.outer(v, (v @ Q[k:, :]))
        return R, Q
    else:
        return R, vs

def apply_q_transpose(vs, b):
    """
    Apply Q^T to vector b using stored Householder vectors.
    """
    m = len(b)
    result = b.copy()
    
    for k, v in enumerate(vs):
        # Apply Householder reflection
        result[k:] = result[k:] - 2 * v * (v @ result[k:])
    
    return result

def solve_triangular(R, b):
    """
    Solve the triangular system Rx = b using back substitution.
    """
    n = R.shape[1]
    x = np.zeros(n)
    
    for i in range(n-1, -1, -1):
        x[i] = (b[i] - np.dot(R[i, i+1:], x[i+1:])) / R[i, i]
    
    return x

def test_householder_qr():
    """
    Test the Householder QR implementation.
    """
    # Test case 1: Square matrix
    A1 = np.array([[1., 2., 3.],
                   [4., 5., 6.],
                   [7., 8., 9.]])
    R1, Q1 = householder_qr(A1, compute_q=True)
    print("\nTest case 1 (Square matrix):")
    print("Original matrix A:")
    print(A1)
    print("\nComputed R:")
    print(R1)
    print("\nComputed Q:")
    print(Q1)
    print("\nVerification QR - A:")
    print(np.abs(Q1 @ R1 - A1).max())
    print("Verification Q^T Q - I:")
    print(np.abs(Q1.T @ Q1 - np.eye(3)).max())
    
    # Test case 2: Rectangular matrix
    A2 = np.array([[1., 2.],
                   [3., 4.],
                   [5., 6.]])
    R2, Q2 = householder_qr(A2, compute_q=True)
    print("\nTest case 2 (Rectangular matrix):")
    print("Original matrix A:")
    print(A2)
    print("\nComputed R:")
    print(R2)
    print("\nComputed Q:")
    print(Q2)
    print("\nVerification QR - A:")
    print(np.abs(Q2 @ R2 - A2).max())
    print("Verification Q^T Q - I:")
    print(np.abs(Q2.T @ Q2 - np.eye(3)).max())

if __name__ == "__main__":
    test_householder_qr()
