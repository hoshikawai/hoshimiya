# Image Deblurring Project

This project implements image deblurring solutions using LU and QR factorization methods. It processes images by applying and then removing blur using specific blurring kernels.

## Features

- Implements two deblurring methods:
  - LU factorization-based deblurring
  - QR factorization-based deblurring
- Compares performance metrics:
  - CPU time for each method
  - Relative forward error using Frobenius norm
- Generates visual comparisons of:
  - Original image
  - Blurred image
  - LU deblurred result
  - QR deblurred result

## Requirements

- Python 3.7+
- Required packages are listed in `requirements.txt`

## Installation

1. Clone this repository
2. Install the required packages:
```bash
pip install -r requirements.txt
```

## Usage

The program expects two input images (`1250_m1_original.png` and `1250_m3_original.png`) to be located in the specified input directory.

The program will:
1. Create blurring kernels Al and Ar with the following specifications:
   - Al: j=0, k=12 (upper triangular matrix)
   - Ar: j=1, k=24 or k=36 (upper triangular matrix with extra subdiagonal)
2. Apply the blurring kernels to create blurred images
3. Deblur the images using both LU and QR factorization methods
4. Generate comparison plots and performance metrics

To run the program:
```bash
python deblur.py
```

## Output

The program will create an `output` directory containing:
- Comparison plots showing original, blurred, and deblurred images
- Performance metrics including CPU time and relative errors for both methods

## Results Analysis

The program provides detailed performance metrics to compare the LU and QR factorization methods:
- CPU time: Measures the computational efficiency of each method
- Relative error: Measures the accuracy of reconstruction using Frobenius norm
- Visual comparison: Allows for qualitative assessment of the results
