import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import os
import time
from scipy import linalg
from householder_qr import householder_qr, apply_q_transpose, solve_triangular

def create_blurring_kernel(n, j, k):
    A = np.zeros((n, n))
    coeffs = np.arange(k, 0, -1) * (2 / (k * (k + 1)))
    
    for i in range(n):
        start_idx = min(i + j, n - 1)
        end_idx = max(start_idx - k + 1, 0)
        valid_coeffs = coeffs[-(start_idx - end_idx + 1):]
        A[i, end_idx:(start_idx + 1)] = valid_coeffs[::-1]
    
    return A

def analyze_matrix_condition(A, name="Matrix"):
    """Analyze the condition number and singular values of a matrix."""
    U, s, Vh = linalg.svd(A)
    cond = s[0] / s[-1]
    min_sv = np.min(s)
    max_sv = np.max(s)
    
    print(f"\n{name} Analysis:")
    print(f"Condition number: {cond:.2e}")
    print(f"Smallest singular value: {min_sv:.2e}")
    print(f"Largest singular value: {max_sv:.2e}")
    
    return cond, min_sv, max_sv, s

def deblur_tikhonov(B, Al, Ar, lambda_reg=None):
    """
    Deblur image using Tikhonov regularization for the least-squares problem:
    min_X ||AlXAr - B||_F^2 + lambda * (||X||_F^2)
    """
    try:
        cond_l, min_sv_l, _, sv_l = analyze_matrix_condition(Al, "Left Kernel (Al)")
        cond_r, min_sv_r, _, sv_r = analyze_matrix_condition(Ar, "Right Kernel (Ar)")
        if lambda_reg is None:
            lambda_reg = np.sqrt(min_sv_l * min_sv_r) * 1e-2
        
        Ul, sl, Vhl = linalg.svd(Al)
        Ur, sr, Vhr = linalg.svd(Ar)
        sl_reg = sl / (sl**2 + lambda_reg)
        sr_reg = sr / (sr**2 + lambda_reg)
        B_hat = Ul.T @ B @ Ur
        X_hat = np.zeros_like(B_hat)
        for i in range(len(sl)):
            for j in range(len(sr)):
                filter_factor = sl_reg[i] * sr_reg[j]
                X_hat[i, j] = filter_factor * B_hat[i, j]
        X = Vhl.T @ X_hat @ Vhr
        
        return np.clip(X, 0, 1), lambda_reg
    
    except Exception as e:
        print(f"Error in Tikhonov deblurring: {str(e)}")
        return None, None

def process_image_robust(image_path, output_dir, j1, k1, j2, k2):
    try:
        img = Image.open(image_path).convert('L')
        img_array = np.array(img, dtype=float) / 255.0
        n = img_array.shape[0]
        Al = create_blurring_kernel(n, j1, k1)
        Ar = create_blurring_kernel(n, j2, k2)
        blurred = Al @ img_array @ Ar
        lambdas = [1e-6, 1e-4, 1e-2, None]  
        results = []
        
        for lambda_reg in lambdas:
            start_time = time.time()
            deblurred, used_lambda = deblur_tikhonov(blurred, Al, Ar, lambda_reg)
            proc_time = time.time() - start_time
            
            if deblurred is not None:
                error = linalg.norm(deblurred - img_array, 'fro') / linalg.norm(img_array, 'fro')
                results.append({
                    'lambda': used_lambda,
                    'time': proc_time,
                    'error': error,
                    'result': deblurred
                })
        
        if results:
            n_results = len(results)
            plt.figure(figsize=(15, 5 * ((n_results + 2) // 2)))
            plt.subplot(((n_results + 2) // 2), 2, 1)
            plt.imshow(img_array, cmap='gray')
            plt.title('Original')
            plt.axis('off')
            
            plt.subplot(((n_results + 2) // 2), 2, 2)
            plt.imshow(blurred, cmap='gray')
            plt.title('Blurred')
            plt.axis('off')
            for idx, result in enumerate(results):
                plt.subplot(((n_results + 2) // 2), 2, idx + 3)
                plt.imshow(result['result'], cmap='gray')
                plt.title(f'Deblurred (λ={result["lambda"]:.2e})\n'
                         f'Time: {result["time"]:.3f}s\n'
                         f'Error: {result["error"]:.6f}')
                plt.axis('off')
            
            plt.tight_layout()
            base_name = os.path.splitext(os.path.basename(image_path))[0]
            plt.savefig(os.path.join(output_dir, f'{base_name}_robust_k{k2}.png'))
            plt.close()
            
            return results
        
        return None
    
    except Exception as e:
        print(f"Error processing image {image_path}: {str(e)}")
        return None

def main():
    input_dir = "/Users/songyutong/Desktop"
    output_dir = "/Users/songyutong/CascadeProjects/image_deblurring/output"
    os.makedirs(output_dir, exist_ok=True)
    
    image_files = ["1250_m1_original.png", "1250_m3_original.png"]
    j_Al = 0
    k_Al = 12
    j_Ar = 1
    k_Ar_values = [24, 36]
    
    all_results = []
    
    for img_file in image_files:
        input_path = os.path.join(input_dir, img_file)
        for k_Ar in k_Ar_values:
            print(f"\nProcessing {img_file} with k_Ar = {k_Ar}...")
            results = process_image_robust(input_path, output_dir, j_Al, k_Al, j_Ar, k_Ar)
            if results:
                for result in results:
                    all_results.append({
                        'image': img_file,
                        'k_Ar': k_Ar,
                        **result
                    })
    
    if all_results:
        print("\nSummary of Results:")
        print("-" * 100)
        print(f"{'Image':<20} {'k_Ar':>5} {'Lambda':>10} {'Time':>10} {'Error':>10}")
        print("-" * 100)
        for r in all_results:
            print(f"{r['image']:<20} {r['k_Ar']:>5d} {r['lambda']:>10.2e} {r['time']:>10.3f} {r['error']:>10.6f}")
    else:
        print("\nNo successful results to display.")

if __name__ == "__main__":
    main()
